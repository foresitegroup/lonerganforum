<?php

if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
	require_once(dirname(__FILE__) . '/SSI.php');
elseif (!defined('SMF'))
	die('<b>Error:</b> Cannot update database.');

global $smcFunc;

if(!array_key_exists('db_add_column', $smcFunc))
	db_extend('packages');

$columns = $smcFunc['db_list_columns']('message_icons');

if(!in_array('color', $columns))
	$smcFunc['db_add_column']('message_icons', 
		array(
			'name' => 'color', 
			'type' => 'varchar', 
			'size' => 16, 
			'default' => '', 
			'null' => false,
			)
		);

if(SMF == 'SSI')
	echo 'Done!';
	
?>