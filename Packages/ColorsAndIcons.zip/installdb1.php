<?php

	if (file_exists(dirname(__FILE__) . './SSI.php') && !defined('SMF'))
		require_once(dirname(__FILE__) . './SSI.php');
	elseif (!defined('SMF'))
		die('<b>Error:</b> Cannot update database.');

	global $db_prefix;

	$request = db_query("
		SHOW COLUMNS FROM {$db_prefix}message_icons
		LIKE 'color'", __FILE__, __LINE__);

	$exist = mysql_num_rows($request) > 0;
	
	// Add the column if not exist
	if (!$exist) 
		db_query("
			ALTER TABLE {$db_prefix}message_icons
			ADD color VARCHAR(16) NOT NULL
			AFTER iconOrder", __FILE__,__LINE__);
	
	mysql_free_result($request);

	if(SMF == 'SSI')
		echo 'Done!';
	
?>