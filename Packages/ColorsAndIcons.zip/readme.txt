[color=green][b]Author[/b]: Bulakbol   [b]Mod Name[/b]: Colors And Icons   [b]Version[/b]: 1.1
[b]Tested[/b]: Freshly installed SMF 1.1.8 and SMF 2.0 RC1[/color]
[hr][b]Colors And Icons[/b][list]
[li]This modification will change the text color of topic through message icons.[/li]
[li]It will also change the color of subject of the first message in the message view. Apply color to all replies is optional.[/li]
[li]For Example: lamp.gif will change the color of your topic to red, xx.gif use the standard color etc.[/li]
[li]If colors are not applied to all replies, then only moderators and administrators are allowed to change any message icon.[/li]
[li]To add or change the colors assigned for each icon, go to [b]Admin => Smileys And Message => Edit Message Icons => Modify[/b]. Make sure that the "Enable customized message icons" in [b]Admin => Smileys And Message => Settings[/b] is enabled (ticked).[/li]
[li]This mod can be configured by navigating to [b]Admin => Posts and Topics => Topic Settings[/b], "Disable colors for icons" and "Do not apply colors to replies in message view" check boxes.[/li]
[/list]

[b]April 14, 2009[/b]
Updated. Now supports SMF version 1.1.8

[b]April 15, 2009[/b]
Upgraded to version 1.1 - added colors in the drop-down menu.
