[center][size=20pt][color=teal][b][font=tahoma]Board Color and Icons[/font][/b][/color][/size]

[url=http://codes.uniquez-home.com/forums/][b]Live Demo[/b][/url] (Look at color boards and icons.)[/center]

[b]Description[/b]

This simple mod will ligthen up your forums with some color and custom icons on your boards.
This is my 1st mod that I have created for SMF. I have great interest in modding SMF.

[b]Initial Release[/b]
[list][li]You can choose what color you would like each board to be[/li]
[li]You can also add icons after the board name to represent what the board is,
and make it more visual.[/li]
[li]Icon width and height should be 18x18 pixels[/li]
[li]Icon is a little larger, the image will automatically be resized![/li]
[li]Supports Child Board[/li]
[li]Supports Redirect boards[/li]
[li]Will also display Color and Icon on child boards[/li]
[li]Shows board color and icons on the Stats Page[/li]
[li]Pick and choose which boards can have colors and icons[/li][/list]


[b]Package Information[b]
Version: [i]1.1[/i]
Package: Board colour and icons
Supports SMF 2.0

[b]Need Help or have any suggestions for improvement??[/b]

If you need help with this modification, please don't hesitate to post in the support thread.

Also we welcome all feed back and improvements that can be made to this modification.
