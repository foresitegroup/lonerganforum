CBI 1.0 {Custom Board Icons v1.7.5}

Thanks go to:

Kindred for the original code and Daegaladh for the optimized code and to all who participated in the threads at:
www.simplemachines.org, www.smfhelper.info and www.pctweakr.com
and to RebelRose for testing and to Marko "Mazeman" Kaartinen and to ccbtimez for his ideas,time and work in
coding. Thanks to all of you for making this mod possible.

In the icons folder in to your /Themes/default/images/icons/.
create folder which name is the boards id,(meaning only the 
number of the board) where you want custom board icon.
Then put on.png, on2.png and off.png in that folder.

Structure:

forum/Themes/default/images/icons
forum/Themes/default/images/icons/board_id/on.png
forum/Themes/default/images/icons/board_id/on2.png
forum/Themes/default/images/icons/board_id/off.png

For redirect boards use this:

forum/Themes/default/images/icons/board_id/redirect.png

(Where "board_id" is the id number of the board you want the icon to show up for. So for example for your first board on your forum it would look like this:
forum/Themes/default/images/icons/1/on.png)

And now also support theme variations:

forum/Themes/default/images/icons/board_id/_variation/on.png
forum/Themes/default/images/icons/board_id/_variation/on2.png
forum/Themes/default/images/icons/board_id/_variation/off.png
forum/Themes/default/images/icons/board_id/_variation/redirect.png

For example:

forum/Themes/curve_minimal_multicolor/images/icons/1/_Ferrari/on.png

The primary home of support for this mod is at: www.smfhelper.info Please join us there for any further questions.